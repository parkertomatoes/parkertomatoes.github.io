Demo for my new Shooter!!!!!(Maximize and use WordWRAP)

FRANTIC JOURNEY/Space Impakto(Space Devil)

Sorry 'bout the bad looking Sprites..... Drawing is not my forte.

Developers:Richard Eric M. Lope aka Relsoft(Philippines)
	   Eero Pitkanen	aka Eebro(Finland)
	   Adigun Polack	(Usa)
           QB_king_Beta_SS

Library:CosmoX/RelLib(OUR own)
Sprite Editor: PP256

*Press TAB while playing to change drones' formation

The ENGINE:

   1. True Parallax Scrolling(Vertical and Horizontal)
   2. Very FAST!!!!!  Nothing is as Fast as this!
   3. Pixel*Pixel collision detection
   4. Easy to add AI and Sound modules
   5. Object based sprite handler
   6. Script-like outside array indexing
   7. Translucency(RealTime)
   8. 5 map layers(4 in memory and 1 calculated)
   9. vector based motion(integers and single precision if all else fails...)
   10. Can be used with any type of game(RPG,Platformer, even puzzle games) with little        
modification.    
   11. Able to handle Multiple/Variable sized Tiles ans Sprites

Controls:
	Arrow Keys=Ship control
        Spacebar=Fire
        TAB=Change Option/Drone formation
        ESC=Get out!

How to play
       Run FJdemo.EXE
       *if it moves, BLAST IT! If it doesn't, BLAST it anyway!!!!


