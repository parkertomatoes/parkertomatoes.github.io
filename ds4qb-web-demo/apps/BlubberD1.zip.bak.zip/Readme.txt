*** Blubber Dragon Help File - Read it all! ***

10. June 2005

It is recommended that you use your own music files with this game
Check MUSIC\MUSIC.TXT

Sorry if there is bad grammar in this file, and in the game itself.
I'm not a natural English speaker.

Version 2.04
------------
- No EMS support (NOEMS.EXE)! Use BLUBBERD.EXE if you get EMS memory.
  (NOEMS.EXE uses conventional memory to store few off-screen buffers)
  (NOEMS game version is more unstable because of constant file loading)
  1. Run NOEMSLEV.BAT.
  * CONVERT.EXE converts some PCX files to BMP format
  * LEVEL.DAT files are replaced with files using BMPs
  2. Point your shortcut to NOEMS.EXE instead of BLUBBERD.EXE
  * Remember to move the IDLE SENSITIVITY SLIDER to increase game's stability
  (If you don't know what it is...read further)
- CONVERT.EXE allows you to convert graphic files between PCX, BMP and PUT
  * Edit CONVERT.DAT to choose what files to convert and to what format
  (PCX - smallest file size, slowest to load)
  (BMP - common format, big size, fastest to load)
  (PUT - Quickbasic's own format, only useful if you draw with that format)
- Pills made melt marks incorrectly on the ground (Bug only in 2.03)
  * NOEMS.EXE doesn't use this feature at all
- Draco's special ability now immediately corrects colors if affected by drug
- Changed score dropping every 25 secs back to -50 from -40
- DATA\XP.DAT renamed to OS.DAT

Version 2.03
------------
- MP3 compressed sound files - Smaller .ZIP - Sounds take longer to load
- Selecting both sound & music OFF in SETUP doesn't load sound system
* Nosound.exe not required anymore
* Selecting for example sound OFF, music ON in SETUP works better now
- Score sound was not always played - fixed
- Bouncy/Invincibility pill doesn't come as often
- Character speed changes - Draco's stamina now 225
- You now lose a little more weight with white pills

Patch 2.02
----------
- Pill colors were not correctly changed after Big's Fire Breath
- Good/Bad Brown & Purple pills are now easier to recognize
- Add Score drops now 40 (dropped 50) after 25 seconds

Patch 2.01
----------
- Big's Fire Breath didn't reset pills' speed, that where underwater
- Pill underwater speed set from 1 to 2 (Makes water levels harder)
- Draco can no longer swim when lying down
- Draco's stamina set from 200 to 250 + small speed changes
- End of campaign scoreboard now uses a background
- Changed score ranking a bit
- Helium bubbles now really inflate the character
- Other small fixes

Version 2.0
-----------
- Second playable character, Draco RedScale, is ready
- Added full support to add more characters & configure dialog, sounds, etc.
  * All sounds are 22050 Khz, 8 or 16 bit, Mono or Stereo
- New pills: Bouncy, Dark, and Drug
- New hazards: Fatgas, Helium bubbles, and Flooding (Water)
- Weather effects: Rain, Lightning and Snow
- Terrain: Slippery (No instant stop) and Sticky (1/2 speed)
- Level specific sounds (Background sound and different footstep sounds)
- Scoring - Level skipping doesn't give high score
- New campaigns! Finally! (I hope they are challenging enough)
- Mouse Support (Control & Menus, F9 toggles during game)
- Characters can jump (Up Arrow or Right Mouse Button)
- Added MO3 music files (Mid -> Mod -> MO3) - They are better than nothing :)
* Ability to make your own music list! (Edit Music\Music.txt)
  * OGG music support enabled this time...oops
- Better SETUP.EXE program. OS chosen starts BLUBBERD.EXE correctly
  * STARTXP.BAT deleted...Not needed anymore
  * No more BLUBBERD.EXE /XP command line needed
- Old XP.DAT renamed to GAME.DAT + Added many options there
* Most of the options are changeable during game. F10 Saves them to GAME.DAT!
  * GFX level - F2=LOW, F3=MEDIUM, F4=HIGH (Lower=Faster game)
  * Fatigue/Panting sound - F5=ON/OFF (Off=Faster game)
  * Mouse Control - F9=ON/OFF
  * Wait Time (WinXP/Win2k/WinNT only) - F7= -5000, F8= +5000
- Ability to take a screenshot (Only one at a time) - F12
  * Creates SCRNSHOT.BMP to OTHER directory
  * There is also my old drawings in OTHER directory :)
- Ability to draw background in front of player's character
- Game code spread to many files due to memory limitations
  * BLUBBERD.BAS, BLUBBER2.BAS, DECLARS.BAS (+BLUBBERD.MAK)
  * LIB directory renamed to CODE (Contains game-code + libraries)
- Find out the rest yourself...

Version 2.0 Pre-Release
-----------------------
- WinXP, Win2k and WinNT support (Tested with XP, Edit DATA\XP.DAT)
  * STARTXP.BAT added, BLUBBERD.EXE /XP parameter needed to play
  A second character to choose from (Test only)
  * Ability to add more characters (Edit DATA\CHARS.DAT)
- More levels
  * Ability to add more levels (Edit DATA\LEVELS.DAT)
- Refined gameplay:
  * Added indestructible terrain
  * No more waiting when fattening up
  * Levels begin from start after death
  * Backspace-key returns to level & character selection screen
- Game music (No files in PreRelease, I use Jazz2 music - no distributing)
  * Put your music in MUSIC folder and edit DATA\LEVELS\*\*.LEV file to play it)
- New graphical effects: Bubbles from character's mouth
- Other things not worthy of mentioning (ok, sound volumes, graphics, etc.)

Version 1.1
-----------
- Special pills (Fast running, slowness, extra life, megafat, randomize fatness)
- Text messages
- Every 25 seconds causes one more pill to drop
- Small sound volume adjustments
- Small graphical changes
- START.BAT added

FUTURE ?  (From most important to least important)
--------------------------------------------------
- More campaigns
- More characters & their special abilities
- Better, more detailed graphics
- Character & Level Editors
- Character animations (jumping, swimming, idle)
- More hazards & more ways to avoid them (Crouching With Down Arrow)

? Two player mode (simultaneous)
? Clothes (Drawn on normal character graphics)



-------------------------------------------------------------------------

Blubber Dragon is a FREEWARE game made by Draco RedScale.
The author is not responsible if improper use of the game causes damage
to your computer. The game requires EMS (Expanded) memory and Win95/98/ME/
XP/2000/NT operating system. You also need quite fast computer, (P233?)
because of my bad coding knowledge.
!!! Run SETUP.EXE before running the game to set sound settings !!!
!!! WinXP/2000/NT users: Read the tricks to get this game to work !!!
Send suggestions, hints and bug reports to janne.koponen@saunalahti.fi.
Tell me how to make the game even better!
You can also visit WWW.SIRKAIN.NET -> FORUMS -> INFLATION
-> AN INFLATION GAME MADE WITH QUICKBASIC V.4.5

Blubber Dragon is a FREEWARE game, which means that:
You can do with my code and graphics whatever you like -
However if you use them anywhere, give me credit for what I have done.

The game is made with QuickBasic V.4.5. using DirectQB 1.61 + DQBRel
libraries for graphics and DS4QB++ 1.2 for sound. Credit to the makers
(Angelo Mottola - DirectQB, Richard Eric M. Lope aka Relsoft - RelLib,
Chris Adams aka Lithium - DS4QB++).



*** What needs to be done to get the game working ***

The game uses DirectQB's DQBsetFrameRate and DQBframeReady routines
to time the game 40fps. These don't work in WinXP, 2000 or NT, so
the time to wait in every frame must be entered in DATA\GAME.DAT!
USE F2-F9 DURING GAME TO CHANGE THE SETTINGS. F10 SAVES THEM!
Or edit the file with NOTEPAD or other simple text-file editor.
Game.txt is a help file.

With this help you may get the game running
-------------------------------------------
1. Remember to run SETUP.EXE before running BLUBBERD.EXE! Choose right OS!
2. Make a new shortcut to Windows' desktop. Point it to BLUBBERD.EXE.
UPDATE: If you don't get EMS memory, point to NoEMS.EXE.
Right click the shortcut. Select PROPERTIES.
- MEMORY TAB: Change all memory settings to AUTOMATIC (EMS especially).
- MISC TAB: Move the IDLE SENSITIVITY SLIDER two steps to the right.
  Make sure FAST PASTE is ON (right side of the SLIDER).
  Take out all unnecessary windows key combinations (I use only CTRL+ESC).
  I don't recommend using of a screen saver when running the game.
- SCREEN TAB: Full Screen, Fast ROM-Emulation, Dynamic Memory.
3. Close all unnecessary programs from Windows' desktop to free memory.
4. Run the shortcut. Check if the game runs too slow, fast or at all.
5. Use F2-F9 to toggle settings (not in menus), press F10 to save them.

No error messages - Only black screen after long waiting
--------------------------------------------------------
1. Get back to desktop (CTRL+ESC).
2. Close the game (RIGHT CLICK, CLOSE).
3. Press CTRL+ALT+DEL and close DS4QBXX.EXE (DS4QB++ sound system).
4. Edit shortcut: Try moving the SLIDER in MISC TAB more to the right.
5. Retry to start the game.
6. If you get laggy controls, you moved the SLIDER too much to the right.

The game runs, but other problems occur
---------------------------------------
- Controls are laggy - The SLIDER in shortcut's MISC TAB is too far right.
- The game runs too slow or fast - Use F2 to F9 to set game settings.
  F10 saves the settings. Game speed (WinXP/2000/NT) can be changed with
  F7 and F8. Hold Q - The number that counts from 0 to 1000 should take
  25 seconds to count from 0 to 1000.

Game quits with an error message
--------------------------------
- DS4QB++ sound system error (in desktop)
- Error in loading of character or weather sounds (DS4QB++ error)
These happen. Even I get them. You can try to move the IDLE SENSITIVITY
SLIDER in shortcut's MISC TAB more to the right to increase sound system's
stability. If you move the SLIDER too far right, the game itself becomes
unstable/slow. You can turn sounds OFF, but leave music ON in SETUP.
Or just turn them both OFF to disable the sound system.

- EMM driver not found (No EMS memory)
* WinXP/2k/NT - If you don't get EMS even after editing the shortcut
correctly, use NoEMS.EXE.
* Win9x - Look the readme section: "How to get EMS memory in Win9x"
...Or use NoEMS.EXE.

Other errors
------------
Check WWW.SIRKAIN.NET -> FORUMS -> INFLATION
-> AN INFLATION GAME MADE WITH QUICKBASIC V.4.5

or send me an e-mail (janne.koponen@saunalahti.fi)



*** How to get EMS memory in Win9x? ***

- Make a backup of your CONFIG.SYS (Win9x in Drive C, C:\CONFIG.SYS)
- Edit CONFIG.SYS like this:
Change line:
DEVICE=X:\WINDOWS\EMM386.EXE NOEMS
to
DEVICE=X:\WINDOWS\EMM386.EXE RAM

There should also be DEVICE=X:\WINDOWS\HIMEM.SYS before the EMM line.
(If you don't have the lines...add them)
* Save the changes
* Restart system
* Now EMS memory should be selectable when making the shortcut



*** The Game ***

In this game you control a dragon character. The
objective is to bump against the red highlighted wall
to get 3 points each time. When you have enough points,
you advance to the next level.

There are different kinds of pills that rain from the sky.
Everytime you get more points, more and more pills will rain
from the sky. Also one pill more will fall every 25 seconds.
So don't wait for too long.
You have to avoid weight gaining pills: GREEN, BLUE, RED
and BLACK. Other pills cause other effects (see below).

(WEIGHT GAINING PILLS)
Green pill: Low weight gain     = slow down = not good
Blue pill:  Average weight gain = slow down = not good
Red pill:   High weight gain    = slow down = not good
Black pill: Most weight gain    = slow down = not good
When the FAT METER is full, you lose one life. You have 3 lives at start.

(SPECIAL PILLS)
White pill:            Lose weight, +5 Points!
Yellow pill:           Special Ability (Max 3), +5 Points!
Brown pill:            Energy! Fast stamina regeneration!
Darker brown pill:     Dizziness and slow stamina regeneration.
Purple pill:           Extra Life (Max 3).
Darker purple pill:    Megafat. 3 weight gains after a short delay.
Invisible pill:        Randomize fatness (can be useful).
Big black pill:        Dark pill. You become almost blind.
Big green pill:        Invincibility! Bounce freely for a while.
Big (ANY COLOR) pill:  Drug...You see wrong colors...

(OTHER HAZARDS)
Green fatgas clouds:   Slow continuous weight gain when close to them
Helium bubbles:        You become immobilized for a moment
- When close to them, don't look at the same direction where they come
Flooding:              Slowly raising water level - Don't drown!
- Press UP ARROW or MOUSE2 to swim up!

Tip: Most special pills take out other special pill effects.
Run whenever you can! Wait under shelter for a good moment before going.
Use character's special ability (SPACE)!
Hold down debug key Q to see where the mouth moves when you turn around:
Quick turning around is a good way to evade!
Press L to skip a level (No score added from that level)



*** Scoring ***

Every level has a score that adds to your current score when you finish
that level. Press P to pause the game and show those stats.

Every 25 seconds: -50 addscore

Touch red wall: +10 addscore
Touch wrong wall: -5 addscore

Lose weight pill: +25 addscore
Energetic pill: +25 addscore
Invincibility pill: +50 addscore
Randomize fatness: +50 addscore (risky)
Extra life: +150 addscore

Dizzy pill: -15 addscore
Dark pill: -25 addscore
Drug pill: -25 addscore
Helium inflate: -25 addscore
Megafat pill: -50 addscore

Oh...Playing the game with lower GFX settings makes the game easier...



*** Characters ***

Name: Devon "Big" GreenTail  - Copyright Draco RedScale
Race: Green dragon
Special Ability: Fire Storm (Destroys all pills and helium bubbles)
Maximum weight to gain: 600
Maximum stamina: 150
Speed: Slow (no fast slow down when fattened)
Jumping ability: Not good
Can change direction mid-air: No

Name: Draco "Action" RedScale - Copyright Draco RedScale
Race: Red dragon
Special Ability: Speed Boost (Run power + Lose special pill effect!)
Maximum weight to gain: 500
Maximum stamina: 225
Speed: Fast (fast slow down when fattened)
Jumping ability: Average
Can change direction mid-air: Yep



*** Keys ***

Left Arrow           - Move Left
Right Arrow          - Move Right
Up Arrow (or Mouse2) - Jump/Swim up!
Space Bar            - Use Special Ability
CTRL (or Mouse1)     - Sprint/Run
P  - Pause (Shows also current SCORE)
M  - Your own music list (Won't work without editing Music/Music.txt first)
F1 - Help
F2 - Low GFX level (slow computer)
F3 - Medium GFX level
F4 - High GFX level (fast computer)
F5 - Toggle fatigue/panting sound On/Off (Off increases game's speed)
F7 - Increase game speed (WinXP/2000/NT) by 5000
F8 - Decrease game speed (WinXP/2000/NT) by 5000
F9 - Mouse control On/Off (I play with keyboard - Draco RedScale)
F10 - Save current F2-F9 settings to DATA\GAME.DAT
Q  - A debug key -> Hold down to show some info
L  - Skip a level (No score added from that level)
Backspace - Go back to campaign & character selection screen
ESC - Quit the game



*** How I can make a new character or a campaign to the game? ***

Character: Check DATA\CHARS\MAKE-OWN\HOWTO.TXT
Campaign:  Check DATA\LEVELS\MAKE-OWN\HOWTO.TXT



*** Questions about this game that you may have thought ***

Q: I have a lot of cool improvement ideas for this game.
A1: Send post to my e-mail janne.koponen@saunalahti.fi.
A2: Tell your idea in WWW.SIRKAIN.NET -> FORUMS -> INFLATION
-> AN INFLATION GAME MADE WITH QUICKBASIC V.4.5

Q: Shouldn't there be a plot/story?!?
A1: It's not really essential in an arcade game like this.
A2: OK, a witch has cursed the dragon...There...feel any better now?

Q: Why there is only dragons in this game?
A1: Cause I love dragons, and I don't know how to draw anything else :)
A2: Add your own character in the game and share it with everyone else!

Q: This game sucks!
A: What's wrong in it? Give me feedback!

Q: Why not make a real windows version of the game?
A: As I said...I'm NOT that good programmer.

Q: Why are the game's graphic files in PCX format?
A: PCX files don't take much space, and the drawing program I use works
   best with them. 256 color BMP files are also supported.
   All graphic files must have the same palette to show correct colors!



==================
- Draco RedScale
