Tales Of Alunia Demo V0.1

By Fenris Productions

This was a small demo completed rushly for the Qlympics 2001. By the time you are reading this, there are probably
updates in our web page. Our adress is still undecided, so if you want to know it e-mail me at fabiorodella@yahoo.com.


Requirements:

DirectX 3.0 or higher for music (Direct Sound for Qbasic)
2000 kbytes of free EMS memory
Sound Blaster 16 or 100% compatible

Note 1: If your sound card doesn't have wavetable synthesis, download WinGroove at www.download.com. It will greatly
        improve the music quality in Tales Of Alunia

Setup sound card:

Add the following line to your AUTOEXEC.BAT file.

SET BLASTER=Aaaa Ii Dd

Where "aaa" is the hexadecimal base address of your sound card (commonly 220),
"i" is the IRQ number and "d" is the DMA channel to be used. A common setting
would be like this:

SET BLASTER = A220 I7 D1


EMS memory:

Add the following lines on your CONFIG.SYS file:
DEVICE = C:\WINDOWS\HIMEM.SYS
DEVICE = C:\WINDOWS\EMM386.EXE 2000 RAM

Here I am supposing that you have Windows 95/98/ME under the WINDOWS directory.

Note 2: In my computer with Windows ME, I got problems with EMS memory, if the game
        keeps telling you that there's no EMM device, e-mail me so I can tell you what worked for me.


Controls: 
Arrow keys: Move character, select options in menus
Space bars: talk to NPCs, open doors, activate triggers
ESC: calls menu, go back to previous menu
ENTER: swap text box position

