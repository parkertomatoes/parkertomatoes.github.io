--> Zeta Beta 2 Public Release <--

This readme is of a fair size, but PLEASE read it through completely.  There is very important info contained in here.


--> Introduction <--
Welcome,
The second Beta is in many ways  a very different game from the first Beta.  ZetaB2 is more efficient, more fun, and more exciting than ZetaB1.  There are numerous new features, and all graphics have been improved.  Animations are smoother, and the game now features translucency.  However, this is still a Beta.  ZetaB1 was a very early Beta.  The game had not yet been finalized, and things were still being decided on.  ZetaB2 is a much more complete game.  The game engine, and the way maps, graphics, enemies, and other objects are handled is almost the same now as it will be in the final.  Remember, however, that the game is not perfect.  At the moment there are only two available maps.  More will be posted on the website for you to download.  At this point, although a huge amount of work has been completed, there isn't as much to show from this work as one might expect.  Many of the improvements are still hidden, and aren't shown in either of the two maps.  Now that the game itself is fairly complete, however, all those improvements can finally be activated.  So when playing this version of Zeta, keep in mind that the improvements you see are not the only ones that were made.  When you played ZetaB1, what you saw is what the game was like.  When you play ZetaB2, what you see is only a fraction of the potential of the new game.

--> What's new since Beta 1 <--
This section was almost not included in the readme, because so much has changed.

- All ingame graphics have been greatly improved
- The interface has been completely redone, and is also greatly improved
- You may now purchase multiple ships
- In addition to the "Scout" class ship, there are the "Frigate" and "Fighter" classes.
- Weapons purchase and sell now works properly
- Weapons are auto-equipped when you begin a mission
- Maps are now stored in a new, high performance format
- The game supports full translucency.
- Enemy AI is improved, and the AI is now fully scriptable, allowing each enemy to have a unique 
movement and firing pattern.
- Ingame options (volume control, keyboard, etc.) are now available
- All game animations are now smoother and more detailed
- Enemies and weapons now support animation
- Colission detection is carried out in pixel-by-pixel mode, creating a far more accurate and realistic colission model.
- The keyboard handler has been improved.  All keyboard issues are now resolved
- Although there are less weapons to purchase, there is a greater diversity.  You may also now purchase homing missiles
- Options (Wingmen) are available.  These are extremely powerful
- Many new map triggers have been implemented.  For example, the viewscreen size is now customizable, and all ingame speeds can be controlled.  The map trigger system supports dynamic addition of new triggers
- There are now six seperate graphics layers, each capable of moving at a different speed to create distance effects
- Weapon graphics can now be rotated (as seen in the homing missile)
- The entire sound system has been updated.  It is now much faster and more efficient
- Zeta now supports any Windows-based sound card.
- Sound quality has been dramatically increased (now CD quality)
- Sound effects quality has been increased
- Zeta supports Sound Blaster Live Environmental Audio Extensions (EAX)

This list could stretch on and on.  The above are the main improvements.


--> Known bugs and issues <--
- Sound may not work under Windows NT or Windows 2000.  Sound support requires DirectX 3 or higher, and DirectX 6 or higher is recommended.  You will also need to  have the VB6 runtime installed.  If you receive an error message indicating that "MSVBVM60.DLL" was not found, go to http://aethersoft.qb45.com to download the VB6 Runtime.  If sound still does not work for some reason, run the "Sound Disable" utility in your start menu to force-disable sound.

- The game may crash upon purchasing a new ship.  This is a rare error that has only occured on one computer so far.  If this error occurs, use the default "NetherGoth" pilot, who already owns a ship.

- Although the passage of time within the game (day and night) has been re-enabled, the actual color changes (the screen getting darker or lighter) have not been added.  The interface does change, however, so if you begin a mission in the night and end in the day, you will find that in the main base it is daytime.


--> System Requirements <--
Zeta requires a Pentium 166 minimum.  This will be reduced to a 133 after some more optimizations have been made.  Pentium 2 400 is recommended.  DirectX 3 or higher is necessary (for sound).  DirectX 6 or higher is recommended.  The game also requires a VESA compatible SVGA card with 1 MB of VRAM, and 16MB of RAM (32 or more highly recommended).


--> How to play Zeta <--
Run the Zeta shortcut in your start menu.  A divide by zero error may occur.  This is a windows problem, and is not caused by Zeta itself.  Right click on the shortcut to zeta.exe, and in the SCREEN tab, make sure that "Full-Screen" is selected.  In the "Memory" tab, you may also want to select "Protected Mode", since it protects your system in case of any bugs or crashes.  Please contact me immediately if you have problems running the game.

Once you're in, you should see a pilot login scren.  Create a new pilot.  You're now in the base.  Click on the door that's in the upper left (on the second floor) of the base.  This is the hangar.  Click the "buy ship" button.  You have enough funds to buy a fighter, but it's best to stick with a scout.  Name your ship, and accept.  !IMPORTANT! If the game crashes upon buying a new ship, log in with the default NetherGoth pilot account.  This bug will be fixed shortly, and only occurs on some computers.  Once you have your ship, click on the other door on the second floor, in the upper right.  It is partially hidden behind the elevator, but is still well visible.  This is the equipment shop.  Go ahead and purchase what you need.  Once you're equipped, click on the second (center) of the three doors in the lower left of the screen.  This is the simulator room.  Select a ship, a map, and you're ready to go!

If you'd like more cash, click on the green door in the lower right.  10,000 Credits will be deposited in your account.  Needless to say, this feature will NOT be available in the full version of the game.  To configure game options (speed, volume, etc.) as well as configuring your keyboard, click on the small blinking screen on the lower floor of the base, next to the door with the red light.  This is the data console.  While you're here, you may want to click the button entitled "Zeta Team" to see who was responsible for bringing you this game.

Once you're in the game, press spacebar to bring up your console.  Use the arrow keys to move, and CONTROL, Z, X, and C to fire your four weapons slots.  These keys can of course be customized.


--> Final Instructions <--
The game will run fine on most computers.  It has been tested extensively.  If for whatever reason the game does not work, please email aethersoft@hotmail.com with a description of the problem.  Include your CPU type and speed, amount of RAM, graphics card, sound card, and operating system.  Please be aware that this is a Beta, and that it is not a complete game.  It may therefore have bugs.  Please report these as soon as possible so that we can release a patch. 

Thanks very much for testing Zeta, and I hope you have fun with the game!

NetherGoth
Email aethersoft@hotmail.com with all bug reports, etc.
Webpage http://aethersoft.qb45.com