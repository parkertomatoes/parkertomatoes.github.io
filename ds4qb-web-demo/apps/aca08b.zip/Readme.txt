+----------------------------------------------------------------------------+
|                  ACALYPHA v:0.8 / November 21st,2001                       |
|                             4th Release                                    |
|                           Chapters 1 & 2                                   |
|                      http://vgamesoft.hybd.net/                            |
|       My website->    http://mangaelf.8m.net/                              |
+----------------------------------------------------------------------------+
       Number of screens        : 163
       Number of maps           : 9
       Playing time             : about 30 minutes
       Graphics libraries       : 8
______________________
1. Info
�-1.1 whatever
�-1.2 Credits
�-1.3 Version history
�-1.4 Player.EXE
�_____________________
2. Gameplay
�-2.1 Controls
�-2.2 Basics
�-2.3 Game screen
�-2.4 Requirements
�_____________________
3. Is this a bad game?
�-3.1 How to tell me
�-3.2 Known bugs
----------------------

1. Info:----------------------------------------------------------------------
   1.1 whatever:
       Project started: January 2000, then stopped. Continued: April 2000
       Yes, It's a zelda clone. I couldn't find a good zelda clone from web
       (or a good NEW zelda clone at least)
       so I decided to continue my old project, this is the result...

       Anyways, now this project has been going for about two years and now
       I'm atleast abit wiser than back then so I know this game sucks.
       It is quite embaressing to let it out but what the heck, I've worked
       for it too much just to let stay on my hd.

   1.2 Credits:
            Toni Svenstr�m   :  Programming, Music, Graphics,
                                Level design, Game design
            Angelo Mottola   :  Graphics&Keyboard routines (DirectQB)               
            AetherSoft       :  Music&Sound routines (Ds4QB)
            Mikko Koistinen  :  Music, Game design, Testing
            Wingroove        :  ...I stole the instruments from it, hope
                                   it's not too illegal...
            Kristoffer Str�m :  Helping out with the story, making
                                me get interested with the project again
            Tuomas Malinen   :  Testing
            Tomi Lyyvuo      :  Testing
            Jani Saxberg     :  Testing
            Tero Lassila     :  Testing, 'constructive critisism' 

   1.3 History:
       v:0.1 -Lousy graphics, couldn't hit monsters, 2 test screens...
       v:0.2 -Scanned graphics, hitting, added potions,crystals,
              more accurate moving, death animation, 11 screens,AdLib music,
              sound FX.
       v:0.3 -Time of day changes, different monsters at night,
              less buggy wall hitting, dialog screens
             -Name ideas: Acalypha ,Dragon Ryo... not too good, eh?
       v:0.4 -The name is Acalypha, more music, updated sound system,
              Main menu, changed potion button from enter to space,
              Intro text.
Rel 1  v:0.5 -Game menu system, menu music, test logo thingy,
              Demo script language.
Rel 2  v:0.6 -Enemies can carry different items, 8 items, when you
              get an item a window tells about it, Item special FX, Item menu,
              Enemies can't appear right next to player, Moving npcs,
              Better enemy code, Particles, New enemy type, more graphics.
Rel 3  v:0.7 -Better enemy code again, Enemy/npc places can be defined,
              Wind, Enemies blow up to pieces, Removed
              cinema script language(out of memory), Better dialog script
              language, Lighting, PAK format to put all the screens in one file,
              Removed the ugly sidebar(to the top of the screen),
              Block/Floor animations, Some story done, Some characters
              designed, New monsters,
              I HAD TO REMOVE THE SPELL SPECIAL FX BECAUSE THE DAMN QB
              RAN OUT OF MEMORY AND I SURE THE HELL AINT GONNA WRITE
              2000 LINES ALL OVER AGAIN!! 
Rel 4  v:0.8 -Chapter 2 and the stuff in it, I FINALLY got a new pc and a
              new screen so making the game should be less painful,
              Digital(mod) music and SFX, Big monsters!,
              Story totally written, Player.EXE, Pushable blocks,
              Monsters adjusted abit

   1.4 Player.EXE:
            Player.exe is just a little mod player which you can play
            acalypha music with and see the song names and authors.

-----------------------------------------------------------------------------

2. Gameplay:------------------------------------------------------------------
   2.1 Keys:
       Arrow keys = Move / Select in menus
       Alt        = Hit  / Talk / Accept in menus
       Space      = Use Item
       Esc        = Game menu 
       Enter      = Accept in menus

   2.2 Basics and hints:
       *Every time you kill a monster you get a crystal.

       *You can only save in places with an altar.
         Save points are shown as a black box on map.

       *Sometimes when you kill a monster you get an item.

       *You can dodge a "bullet" if you turn against it and
        don't use your weapon at the same time.

       *There are obstacles (i.e. Green plants)  in some screens which
         you can only get trough with a certain weapon.

       *There are 8 different non-story items in the game, you have to
        choose the item you want to use from the ITEMS menu

       *Sometimes it's useful to talk to people twice or more...

       *Save your game in different save game slots; you might find yourself
         fighting a boss and only have one hp left...

   2.3 Game screen:

           1    2    3   4
        _______________________________
        |  +   �      ���       | <-Health
        | alt space    ���         | <-Experience
        |---------------------------L1----| <-Level
        |                                 |
        |                                 | 1=Weapon
        |                                 | 2=Item
        |        the game itself          | 3=Crystals
        |                                 | 4=Map
        |                                 |
        |                                 |
        -----------------------------------

   2.4 Requirements:
       I'm not sure about this one...
       Maybe a 486 with some ram, VGA/MCGA,
       Some soundcard and win95 or above for music and sound FX.

-------------------------------------------------------------------------------

3. Is this a bad game? Does it even work?!-------------------------------------------------
   3.1 How to tell me
       Send comments or whatever to MangaElf@Hotmail.com , pleeeze ^-^;

   3.2 Known bugs
       -Hasn't worked on all computers I've tried it on
       -Enemies might get into blocks 
       -Enemy speed problems...
       -Colliding doesn't always work right
       -Sound FX don't work right
       -'Kay, my stupid engine can't do proper bosses... who cares
          nobody likes boss monsters anyway.
               
