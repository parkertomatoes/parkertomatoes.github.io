The Secret of Cooey III Demo

(c) 2000 - 2001 Darkness Ethereal
General comments may be sent to: darkdread@hotmail.com

---------------------------------------------------
CONTENTS

    A: WELCOME
        I   - ABOUT SOC3 DEMO
        II  - MINIMUM REQUIREMENTS

    B: GAMEPLAY
        I   - CONTROLS
        II  - HOW TO PLAY
        III - HINTS AND TIPS

    C: CREDITS
        I   - CREDITS

    D: LEGAL
        I   - LICENSE
        II  - DISTRIBUTION

---------------------------------------------------
A: WELCOME
-----------
I   - ABOUT THE SOC3 DEMO

Thanks for downloading the Secret of Cooey III demo
by Darkness Ethereal.  This is a console style role
playing game.  What is console style? It is a style
of RPG which evolved on console systems such as the
NES.  Final Fantasy and Dragon Warrior are perfect
examples of this type of game.

This demo took much longer than expected to finish.
Once again, this was due to my need (obssession)
for only the highest quality game.  That, and the
fact that some of the story was revised at the last
moment, resulted in a few delays.

At last though, the demo is complete.  All in all,
this demo constitutes of about 12% of the entire
game.  It is, esentially, the prologue which sets
up the story of SoC3.  If you wish to learn more,
than read on.  If not, then go play the demo! Don't
forget to send us some feedback.

Cheers!

Darkness Ethereal (SoC Team 1.2)
-----------
II  - MINIMUM REQUIREMENTS

Windows 95/98/ME
Pentium 100 CPU
16MB RAM
7.5MB Free Hard Drive Space
16bit Stereo Sound Card

Use those requirements as a guideline.  SoC3 Demo
should play fine on most 486 machines, but it will
be slow.  The above is what you need to truly enjoy
the game.
---------------------------------------------------
B: GAMEPLAY
-----------
I   - CONTROLS

Keyboard:
Arrow Keys - Move Cooey / Hand Pointer
<SPACEBAR> - Call Menu
<ENTER>    - Talk to NPCs / Accept Selections
<ESC>      - Cancel Selections / Quit Game
-----------
II  - HOW TO PLAY

If you've ever played a console RPG before, then
you will have no trouble playing the SoC3 Demo.  If
not, then read on for some hints on how to play the
game.

Navigating the World:

It's pretty simple.  Use the arrow keys to move
Cooey around.  In towns, and certain other areas,
you can enter houses by walking through the doors.
You can also talk to other characters by walking up
to them and pressing the space bar.

Calling up the in game menu is done by pressing the
enter key.  You can use the arrow keys to move the
cursor in the menus.  Enter selects an option and
the escape key backs out.

Buying items is handled the same way as the in game
menu.  You use the arrow keys to move your cursor.
The enter key selects the item you wish to purchase.
At this point, you can use the arrow keys to select
the amount of the item you wish to purchase.  If
you don't have enough money to buy the item, you
will not be able to select it.

Battles:

A fight can occur randomly in most areas, except
for towns.  When then battle begins, action bars
will slowly increase for each character.  When the
action bar is full, you may select an action for
that character.  Possible choices are to fight,
use magic, use an item, or run.  To attack one of
your enemies, select fight, and then select the
enemy you wish to attack.  The damage you have done
will be indicated by a number, that scrolls over
the enemy.

As enemies attack, you should keep an eye on your
characters' HP, or hit points.  Once they are down
to 0, your character is dead, and cannot fight any
more.  To prevent characters from dying, you may
use curing items if you have them, or curing
spells.  Try to use your spells sparingly, as, they
rely on MP, or magic points.  Each time a spell is
cast, your character will use up some magic points.
If they do not have enough magic points to cast a
certain spell, you will not be able to use that
spell.  Magic points may be refilled by using items
called Ethers.

Once a battle is won, your characters will gain
gold and experience.  Gold can be used to purchase
new weapons, armor, and items.  Once enough
experience is gained, your characters will increase
in levels.  When they do this, their stats increase
and they become stronger.
-----------
III - HINTS AND TIPS

* If you cannot kill an enemy, try a different
  tactic.  If you still cannot kill them, fight
  other enemies to increase your levels, and then
  try again.

* In a losing situation, it is best to run from the
  enemy.  Be careful though, as you will not be
  able to run from some enemies.

* Talking to one of the butlers in Cooey's house
  will allow you to rest, and replenish your HP and
  MP.

* You can save your game anywhere on the world map.
  Do this by hitting enter, and selecting save from
  the menu.
---------------------------------------------------
C: CREDITS
-----------
I - CREDITS

    PROGRAMMING
        DarkDread

    GRAPHICS
        DarkDread

    CG RENDERS
        DeviusCreed
        Tyranny

    MUSIC
        DarkDread

    SOUND EFFECTS
        DarkDread
        Public Domain

    ADDITIONAL LIBS
        The Brain
        Nethergoth
        Nekrophidius
        Milo Sedlacek
        Joe Huber Jr.

    THANKS
        Everyone who waited patiently for this
        demo. :)
---------------------------------------------------
B: LEGAL
-----------
I   - LICENSE

THE SECRET OF COOEY III DEMO IS FREEWARE.  IT MAY
BE USED AND DISTRIBUTED FREELY.  NO FEE MAY BE
CHARGED FOR ITS USE OR DISTRIBUTION.  NO WARRANTIES
ARE GRANTED WITH THIS PRODUCT.  BY USING THIS
PRODUCT, YOU AGREE TO THESE LICENSES.
-----------
II  - DISTRIBUTION

IF YOU WISH TO DISTRIBUTE THE SECRET OF COOEY III
DEMO, YOU MAY DO SO, AS LONG AS NO FEE IS CHARGED
FOR ITS DISTRIBUTION.  IF YOU WISH TO CHARGE A FEE,
PLEASE CONTACT DARKDREAD@HOTMAIL.COM FOR LICENSING
OPTIONS.
---------------------------------------------------
(c) 2000 - 2001 http://welcome.to/DarknessEthereal
