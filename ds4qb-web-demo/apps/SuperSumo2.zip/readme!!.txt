This package contains all the original game files 
plus 3 extra ones added by me.

SUMO_WinXP.EXE is the original SUMO.EXE file patched 
with Plasma's DQBsetFrameRate in DirectQB 1.5+ fix
so that the game can be played in Windows XP too.

NOSOUND_WinXP.EXE is the original NOSOUND.EXE file patched 
with Plasma's DQBsetFrameRate in DirectQB 1.5+ fix
so that the game can be played in Windows XP too.

RunMe!_NoSound.pif is a shortcut which runs the second file 
with EMS memory allocated. I pretty sure NOSOUND_winXP.EXE 
should work in other Windows version too, so first try to run 
the game with RunMe!_NoSound.pif no matter which Windows 
version you are using. If this fails, you'll need to allocate 
the EMS memory yourself (create a shortcut for NOSOUND.EXE).

The fact that patched files end with "WinXP" doesn't 
necessarily mean they won't work in DOSBox (depends on 
the game and not on the DQBsetFrameRate patching).

If EMS memory allocation doesn't work on your PC, try
Plasma's EMS Magic utility (www.phatcode.net). It works best 
together with VDMSound and when ran through a batch file.

I was unable to run the game with sound/music on my PC
(Windows XP installed). DOSBox didn't help.

~ Lachie D. November, 2006.