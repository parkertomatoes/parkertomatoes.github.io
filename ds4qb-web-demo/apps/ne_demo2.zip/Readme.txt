		*** NEBULA-ENGINE II: DEMO version 2.0 ***

Nebula Software, 2004


Thanks for trying this demo!
The second demo of N-E II already. This demo contains several new
features, but the main point is the weapon handling routines I have
add to the engine since the previous demo.

I want to credit Angelo Mottola and Petter Holmberg of Enhanced
Creations for the great job they did by coding the RT Engine.
Nebula Software takes no responsibility for any damage caused by this
program.


* CONTENTS

- playing the demo
- controls
- what is nebula-engine II?
- new features of version 2.0
- features of version 1.0
- next releases
- if you like this demo...


* PLAYING THE DEMO

Start the demo by running DEMO.BAT in the main directory. First you
have to run SETUP.BAT to configurate the sound-driver.

NOTE: 	In case of Windows NT/XP/2000, you have to set the amount
	of XMS-memory to the maximum:
	go to: Program/Start.EXE => properties => memory => XMS

The sound-driver (DS4QB++) sometimes causes an error. If this happens
frequently or the program doesn't run at all, you can always play the
demo by running DEMONSND.BAT.
The sound-driver doesn't work properly anyway; especially the sound
playback gets stuck when it has to play multiple sounds at once.


* CONTROLS

Sorry, the engine supports customize keys, but I was to lazy to code
a program to configurate them.

<mouse>		= look around
<arrow keys>	= walk, strafe
<A>, <D>	= turn
<R. SHIFT>	= jump
<CTRL>		= duck
<SPACE>		= open door
<ENTER>		= dynamic palette demonstration
<ENTER>,
<L. MOUSEBUTTON>= fire weapon
<1>		= select weapon 1
<0>		= deselect weapon
<TAB>		= select map


* WHAT IS NEBULA-ENGINE II?

This engine is a modification of the RT Engine by Angelo Mottola and
Petter Holmberg of Enhanced Creations. I try to change this engine
into a first-person shooter, following three steps:

- optimizing the raycasting engine
- adding weapon handling and projectile firing
- adding enemy's

After every step I will release another demo, so this is the demo of
the second step.


* NEW FEATURES OF VERSION 2.0

Since the previous demo, the additional features are:

- 320x128 resolution animated weapon textures * 
- projectile firing * 
- screen flash-light while firing * 
- objects can be destroyed * 
- renewed message display * 


* FEATURES OF VERSION 1.0

The starting point of this engine is RTE. Additional features are:

- optimized controls
- animated textures (#)
- animated sprites
- dynamic palette handler (#)
- coloured fog (#)
- sound support, thanks to DS4QB++ (#)
- gravity (results in "realistic" jumping) (#)
- swim option (jump into the water, and find out...) (#)
- level-editor (not included in this demo)

(#) were not included in Nebula Engine I


* NEXT RELEASES

I don't know when the next demo will be released. Stay tuned, the
Nebula Software website will keep you posted...


* IF YOU LIKE THIS DEMO...

Visit the Nebula Software website for the latest news and releases.
You can also download other Nebula projects here:

- Nebula Engine: Capture the Flag
- Resistance

www.nebulasoftware.tk
 or:
http://home.hetnet.nl/~nebula

e-mail: nebulasoftware@gmx.net