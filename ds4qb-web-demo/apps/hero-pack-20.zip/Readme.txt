
 **************************
 *  - H E R O - pack 2.0  *
 *                        *
 *(leveleditor included!!)*
 *      (1999-2002)       *
 *                        *
 *                        *
 *        by BAS          *
 *   (www.herogame.de)    *
 **************************


06.01.2002

[EINLEITUNG]

 Hero ist einem Jump'n'Run ziemlich �hnlich, nur das man hier nicht springen muss,
 sondern fliegen kann! =)
 
 Der Held st�rzt sich am Anfang ohne richtigen Grund in eine Schlucht. Er ist ausserdem mit
 einem Laser ausgestattet, um sich l�stige Gegner vom Hals zu halten und blockierte Wege  
 freizur�umen. 

 Ausserdem liegt ein Leveleditor bei!


[STEUERUNG]

  nach oben  : Pfeil oben
  nach links : Pfeil links
  nach rechts: Pfeil rechts

  Laser      : Leertaste

  F          : FPS anzeigen

  ESC        : Men�


[START]

 Starte das Spiel mit HERO.EXE, es erscheint eine kleine Intro-Animation (3D!). W�hrend dem
 Intro kannst du INFO eingeben um weitere Informationen anzuzeigen...
 Wenn sich das Logo zu drehen anf�ngt, kannst du mit ESC zum eigentlichen Spiel wechseln.
  
 Sollte dieser �bergang nicht funktionieren, kannst du das Spiel auch direkt mit G.EXE 
 starten!

 Hinweis: Das Intro greift auf die Datei "3DConfig.cfg" zu. Du kannst sie selbst anpassen!

 Num Lock muss im Spiel �brigens ausgeschaltet, in den Editoren aber eingeschaltet sein.


[MEN�]

 Ich denke, das Spielmen� erkl�rt sich von selbst, bei "Spiel speichern" wird allerdings nur 
 der jeweilige Level gespeichert, es bringt also nichts, mehrmals in einem  Level zu
 speichern.

 In der Highscore-Liste werden die 5 Spieler angezeigt, die das Spiel in der k�rzesten Zeit
 durchgespielt haben...


[LEVELEDITOR]

 Nicht vergessen, dass du auch neue Levels erstellen kannst! Im Verzeichnis EDITOR sind 3
 Programme, die du brauchst...

 1. TEXTUREN.EXE (Texturen freischalten, nur 1 mal ausf�hren)
  Wenn du eigene Levels bauen willst, musst du als erstes (und nur 1 mal!) TEXTUREN.EXE 
  ausf�hren. Damit die Spieltexturen so umgewandelt, dass du sie weiterverwenden kannst.

 2. TEXED.EXE    (Textureditor)
  Mit dem Textureditor kannst du Texturen ver�ndern, neue erstellen usw...

 3. LEVED.EXE    (Leveleditor)
  Das ist der eigentliche Leveleditor.
  Weitere Infos gibts im EDITOR Verzeichnis...

 Alle Levels wurden �brigens mit dm Leveleditor erstellt. Nur in Level 11 und 12 hab ich   
 etwas nachgeholfen...


[SONSTIGES]
 
 Wen es interessiert... 

 HERO ist komplett in Qbasic geschrieben...!
 Ich habe irgendwann im November 1999 angefangen... 

 F�r Sound + Musik hab ich "DirectSound for QuickBasic 2, version 1.1" von David Schnur
 verwendet (www.AetherSoft.com). :)

     
 "herogame.de" ist die offizielle Heropage! Dort werde ich neue Updates und mehr zur
 Verf�gung stellen! ;)

 Vielleicht starte ich ja auch einen Online-Wettbewerb, der besten Spieler!! 
 (falls jemand interessiert ist...)
 Mailt mir einfach eure Highscores (hghscore.hro) an "masta@herogame.de" !
 Wenn du einen eigenen Level gebaut hast, kannst du ihn mir nat�rlich auch schicken! Wenn du
 eigene Texturen verwendest, vergiss nicht sie auch mitzusenden.


by Masta!

  

HOMEPAGE:   www.herogame.de
EMAIL   : masta@herogame.de

