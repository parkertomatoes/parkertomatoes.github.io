* SQUEALER TNT *  
* Marcus Kasumba * 14-Jan-2003 * piptol@yahoo.com *
=========================================================================
IMPORTANT
- Windows XP users will need to enable XMS memory to run this game
- If running through MS-DOS, launch game with NOSOUND.BAT
=========================================================================
MENU:
	Pig Tales	- Single player story mode
	Blastfest	- Customisable 1 or 2 player carnage
	Hi Scores 	- Best 'Pig Tales' players
	Controls	- Choose your keys
	Quit		- Chicken out to real-world safety

=========================================================================
PLAYING THE GAME
Pig Tales:
Progress through each round until the final showdown with Mr Pig!

Blastfest:
1 player - Create a custom battle to see how hard you really are.
2 player - Player with most points at end becomes Blastfest Champion!

Default Keys:
Player 1 - W,S,A,D,F
Player 2 - Arrow Keys, Return
=========================================================================
POINTS SCORING

-Each explosion can score multiple hits. The point ranges below indicate
the possible score based on number of hits on a single pig.
-Blastwave Bomb causes every bomb on the screen to detonate. Each
exploding bomb will score as the Blastwave (5 - 30)

     Bomb                       Points Scored
     ------                     -------------                           
     Standard Bomb                  1 - 6
     Basketball Bomb                2 - 12
     Poison Gas                     3 - 18
     Crazy Bomb                     4 - 24
     Blastwave Bomb                 5 - 30
     TNT                            6 - 36

-Round clear points are cumulative e.g. a Perfect Blastwave finish would
receive 250 points (+50 Blastwave, +100 Perfect Bonus, +100 health bonus) 

     Finish                     Points Scored
     ------                     -------------
     Perfect                         +100
     Blastwave                       + 50
     TNT                             + 25
     Round clear                     + Your health (1 - 100)

-An extra life is awarded every 1000 points!

=========================================================================
GAMEPLAY HINTS
-Earn extra points for stylish finishes: TNT, BLASTWAVE & PERFECT
-Set off big chain reactions for big points!
-Each pig type uses a different strategy: learn the attack patterns!
-Press ESC to quit back to the menu during the game
-Press ESC to skip the story screens
-He who fights and runs away, lives to fight another day!
=========================================================================
GAME ISSUES:
Q) How do I get out of the hi-scores screen?
A) Just press a number. You can't use the keypad for menu selections.

Q) The controls are sometimes a bit unresponsive
A) Keyboards aren't really designed for gaming, and how well they cope
varies from one to another. This problem is only likely to occur in
2 player mode. Also note that some key combinations work better than
others. The default keys work well enough (on my PC anyway :-/)

Q) I get a warning about an XMS Manager?
A) Squealer TNT needs XMS memory enabled.

Q) How do I set up XMS memory?
A) In Windows, right click on SQUEALER.EXE, go to 'properties' and enable Extended (XMS) memory through that.(e.g. In Win95 it's on the 'Memory' tab).

Q) Can I run in pure DOS mode?
A) Yes, but make sure you run NOSOUND.BAT

Q) The game crashes on start-up or drops back to Windows
A) You may have a soundcard incompatible with the sound engine. If this
is the case, run the game with NOSOUND.BAT

Q) The game somethimes pauses momentarily at the end of a round?
A) Yes, it's an issue sound engine that is beyond my control. Just give
it a moment to sort itself out, it's only a couple of seconds.

Q) I've found a diffent problem not listed here?
A) Drop me a mail at piptol@yahoo.com and I'll look into it. 

=========================================================================
HISTORY:
Squealer TNT v1.2
Released 14-Jan-2003
- New points scoring system
- Extra life every 1000 points in Pig Tales
- Now TNT will really rock their world.. watch the screen shake!
- Some sound effects resampled
=========================================================================
Squealer TNT v1.12
Released 10-Jan-2003
- Bug fix: The Blastwave finishes now register for bonus points!
=========================================================================Squealer TNT v1.11
Squealer TNT v1.11
Released 06-Jan-2003
- Controls now saved so you don't have to reconfigure every time
- Bug fix: If you finish the game, it now saves the hi scores
=========================================================================
Squealer TNT v1.1
Released 05-Jan-2003
- Now with added explosion chain reactions.. have fun ;)
=========================================================================
Squealer TNT v1.01
Released 05-Jan-2003
- Bug fix: you can now select 50 bombs (Blastfest) without it crashing :)
=========================================================================
Squealer TNT v1.0
Released 04-Jan-2003
- First release!
=========================================================================
CREDITS:
 
Program code & graphics	: Marcus Kasumba, Piptol Productions
CosmoX library		: bobby, CosmoSoft
DS4QB2			: David Schnur, Aethersoft
FAR QB			: Eric Cowles
In-game Music		: Remixed from C64 version of 'Psycho Pigs'
Other Music & SFX	: The 'Net, + original samples by Piptol

Thanks to everybody who gave feedback, suggested improvements and
reported bugs. Especially the guys at my forum :)

Visit Piptol Productions at http://piptol.cjb.net
==============================END OF TEXT FILE===========================